package com.example.weighttracker.userinterface

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.weighttracker.R
import com.example.weighttracker.data.WeightEntry
import com.google.android.material.button.MaterialButton
import java.time.LocalDate
import java.time.format.DateTimeFormatter

class WeightAdapter(
    private val onEdit: (WeightEntry) -> Unit,
    private val onDelete: (WeightEntry) -> Unit
) : ListAdapter<WeightEntry, WeightAdapter.VH>(DIFF) {

    companion object {
        private val DIFF = object : DiffUtil.ItemCallback<WeightEntry>() {
            override fun areItemsTheSame(a: WeightEntry, b: WeightEntry) = a.id == b.id
            override fun areContentsTheSame(a: WeightEntry, b: WeightEntry) = a == b
        }
        private val fmt = DateTimeFormatter.ofPattern("yyyy-MM-dd") // matches your form
        private fun formatDate(epochDay: Long) = LocalDate.ofEpochDay(epochDay).format(fmt)
    }

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        private val tvDate = view.findViewById<TextView>(R.id.tvDate)
        private val tvWeight = view.findViewById<TextView>(R.id.tvWeight)
        private val btnEdit = view.findViewById<MaterialButton>(R.id.btnEdit)
        private val btnDelete = view.findViewById<MaterialButton>(R.id.btnDelete)

        fun bind(item: WeightEntry) {
            tvDate.text = formatDate(item.dateEpochDay)
            tvWeight.text = String.format("%.1f lb", item.weightLbs)
            btnEdit.setOnClickListener { onEdit(item) }
            btnDelete.setOnClickListener { onDelete(item) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_weight_card, parent, false)
        return VH(v)
    }
    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))
}
