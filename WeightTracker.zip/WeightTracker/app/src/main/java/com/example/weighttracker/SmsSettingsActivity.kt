package com.example.weighttracker.userinterface

import android.Manifest
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.weighttracker.R
import com.example.weighttracker.auth.SmsSettings
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText

class SmsSettingsActivity : AppCompatActivity() {

    private lateinit var swEnable: SwitchMaterial
    private lateinit var etPhone: TextInputEditText
    private lateinit var etGoal: TextInputEditText
    private lateinit var btnSave: MaterialButton
    private lateinit var btnTest: MaterialButton

    private val requestSmsPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            SmsSettings.setEnabled(this, true)
            swEnable.isChecked = true
            Toast.makeText(this, "SMS enabled", Toast.LENGTH_SHORT).show()
        } else {
            SmsSettings.setEnabled(this, false)
            swEnable.isChecked = false
            Toast.makeText(this, "SMS permission denied. Feature disabled.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms)

        swEnable = findViewById(R.id.swEnableSms)
        etPhone  = findViewById(R.id.etSmsPhone)
        etGoal   = findViewById(R.id.etGoalLbs)
        btnSave  = findViewById(R.id.btnSaveSms)
        btnTest  = findViewById(R.id.btnTestSms)

        // Load saved values
        swEnable.isChecked = SmsSettings.isEnabled(this)
        SmsSettings.phone(this)?.let { etPhone.setText(it) }
        SmsSettings.goal(this)?.let { etGoal.setText(it.toString()) }

        // Toggle asks for permission when turning ON
        swEnable.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                requestSmsPermission.launch(Manifest.permission.SEND_SMS)
            } else {
                SmsSettings.setEnabled(this, false)
            }
        }

        btnSave.setOnClickListener {
            val phone = etPhone.text?.toString()?.trim().orEmpty()
            SmsSettings.setPhone(this, phone)
            etGoal.text?.toString()?.trim()?.toDoubleOrNull()?.let { SmsSettings.setGoal(this, it) }
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        btnTest.setOnClickListener {
            sendIfAllowed("Test from WeightTracker: SMS alerts are working.")
        }
    }

    private fun sendIfAllowed(message: String) {
        if (!SmsSettings.isEnabled(this)) {
            Toast.makeText(this, "SMS is disabled", Toast.LENGTH_SHORT).show()
            return
        }
        val phone = SmsSettings.phone(this)
        if (phone.isNullOrBlank()) {
            Toast.makeText(this, "Enter and save a phone number first", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null)
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show()
        } catch (_: SecurityException) {
            // Permission was revoked
            SmsSettings.setEnabled(this, false)
            swEnable.isChecked = false
            Toast.makeText(this, "No SMS permission.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to send: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
