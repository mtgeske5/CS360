package com.example.weighttracker

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.example.weighttracker.auth.AuthViewModel
import com.example.weighttracker.auth.AuthViewModelFactory
import com.example.weighttracker.data.AppDatabase
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText

class CreateAccountActivity : AppCompatActivity() {

    private val authVm: AuthViewModel by viewModels {
        AuthViewModelFactory(AppDatabase.get(this))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_account)

        val etUser = findViewById<TextInputEditText>(R.id.etNewUsername)
        val etEmail = findViewById<TextInputEditText>(R.id.etEmail)
        val etPwd = findViewById<TextInputEditText>(R.id.etNewPassword)
        val btnRegister = findViewById<MaterialButton>(R.id.btnRegister)

        btnRegister.setOnClickListener {
            val u = etUser.text?.toString()?.trim().orEmpty()
            val e = etEmail.text?.toString()?.trim().takeUnless { it.isNullOrBlank() }
            val p = etPwd.text?.toString().orEmpty()

            if (u.isEmpty() || p.length < 6) {
                Toast.makeText(this, "Username and 6+ char password required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            authVm.register(u, e, p)
            Toast.makeText(this, "Account created. Please log in.", Toast.LENGTH_SHORT).show()
            finish() // go back to login
        }
    }
}
