package com.example.weighttracker.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "weights")
data class WeightEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val dateEpochDay: Long,   // LocalDate.toEpochDay()
    val weightLbs: Double,
    val note: String? = null,
    val createdAtMs: Long = System.currentTimeMillis()
)
