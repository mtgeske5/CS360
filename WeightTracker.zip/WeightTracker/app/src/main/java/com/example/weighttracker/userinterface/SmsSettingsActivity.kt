package com.example.weighttracker

import android.Manifest
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.example.weighttracker.auth.SmsSettings
import com.google.android.material.button.MaterialButton
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText

class SmsSettingsActivity : AppCompatActivity() {

    private lateinit var swEnable: SwitchMaterial
    private lateinit var etPhone: TextInputEditText
    private lateinit var etGoal: TextInputEditText
    private lateinit var btnSave: MaterialButton
    private lateinit var btnTest: MaterialButton

    private val requestSmsPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            SmsSettings.setEnabled(this, true)
            swEnable.isChecked = true
            Toast.makeText(this, "SMS enabled", Toast.LENGTH_SHORT).show()
        } else {
            SmsSettings.setEnabled(this, false)
            swEnable.isChecked = false
            Toast.makeText(this, "SMS permission denied. Feature disabled.", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sms)

        swEnable = findViewById(R.id.swEnableSms)
        etPhone  = findViewById(R.id.etSmsPhone)
        etGoal   = findViewById(R.id.etGoalLbs)
        btnSave  = findViewById(R.id.btnSaveSms)
        btnTest  = findViewById(R.id.btnTestSms)

        // load saved
        swEnable.isChecked = SmsSettings.isEnabled(this)
        SmsSettings.phone(this)?.let { etPhone.setText(it) }
        SmsSettings.goal(this)?.let { etGoal.setText(it.toString()) }

        swEnable.setOnCheckedChangeListener { _, checked ->
            if (checked) {
                // ask permission; if denied we’ll flip back to off
                requestSmsPermission.launch(Manifest.permission.SEND_SMS)
            } else {
                SmsSettings.setEnabled(this, false)
            }
        }

        btnSave.setOnClickListener {
            val phone = etPhone.text?.toString()?.trim().orEmpty()
            val goal  = etGoal.text?.toString()?.trim()
            if (phone.isEmpty()) {
                Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            SmsSettings.setPhone(this, phone)
            goal?.toDoubleOrNull()?.let { SmsSettings.setGoal(this, it) }
            Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
        }

        btnTest.setOnClickListener {
            maybeSendSms("Test from WeightTracker: notifications are working.")
        }
    }

    private fun maybeSendSms(message: String) {
        if (!SmsSettings.isEnabled(this)) {
            Toast.makeText(this, "SMS disabled", Toast.LENGTH_SHORT).show()
            return
        }
        val phone = SmsSettings.phone(this)
        if (phone.isNullOrBlank()) {
            Toast.makeText(this, "Add a phone number and save first", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val mgr = android.telephony.SmsManager.getDefault()
            mgr.sendTextMessage(phone, null, message, null, null)
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show()
        } catch (se: SecurityException) {
            Toast.makeText(this, "No SMS permission", Toast.LENGTH_LONG).show()
            swEnable.isChecked = false
            SmsSettings.setEnabled(this, false)
        } catch (e: Exception) {
            Toast.makeText(this, "Failed to send SMS: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
