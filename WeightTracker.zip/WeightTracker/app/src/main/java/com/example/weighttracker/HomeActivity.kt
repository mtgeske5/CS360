package com.example.weighttracker.userinterface

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.weighttracker.R
import com.google.android.material.button.MaterialButton
import com.example.weighttracker.MainActivity

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        // Buttons
        val btnOpenGrid = findViewById<MaterialButton>(R.id.btnOpenGrid)
        val btnSmsSettings = findViewById<MaterialButton>(R.id.btnSmsSettings)
        val btnLogout = findViewById<MaterialButton>(R.id.btnLogout)

        // Navigate to Weight Grid
        btnOpenGrid.setOnClickListener {
            val intent = Intent(this, WeightGridActivity::class.java)
            startActivity(intent)
        }

        // Navigate to SMS Settings
        btnSmsSettings.setOnClickListener {
            val intent = Intent(this, SmsSettingsActivity::class.java)
            startActivity(intent)
        }

        // Log out → return to login screen
        btnLogout.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }
    }
}
