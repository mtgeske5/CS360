package com.example.weighttracker.userinterface

import android.telephony.SmsManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.weighttracker.R
import com.example.weighttracker.auth.SmsSettings
import com.example.weighttracker.data.AppDatabase
import com.example.weighttracker.data.WeightEntry
import com.example.weighttracker.data.WeightViewModel
import com.example.weighttracker.data.WeightViewModelFactory
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch
import java.time.LocalDate

class WeightGridActivity : AppCompatActivity() {

    private val vm: WeightViewModel by viewModels {
        WeightViewModelFactory(AppDatabase.get(this))
    }
    private lateinit var adapter: WeightAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_grid)

        // Add form (top of screen)
        val etDate   = findViewById<TextInputEditText>(R.id.etDate)
        val etWeight = findViewById<TextInputEditText>(R.id.etWeight)
        val btnAdd   = findViewById<MaterialButton>(R.id.btnAdd)
        val tvEmpty  = findViewById<android.widget.TextView>(R.id.tvEmpty)

        // Grid
        val rv = findViewById<RecyclerView>(R.id.rvWeights)
        val span = if (resources.configuration.screenWidthDp >= 600) 2 else 1
        rv.layoutManager = GridLayoutManager(this, span)
        adapter = WeightAdapter(
            onEdit = { showEditDialog(it) },
            onDelete = { vm.delete(it) }
        )
        rv.adapter = adapter

        // Observe DB -> grid
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                vm.weights.collect { list ->
                    adapter.submitList(list)
                    tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
            }
        }

        // CREATE
        btnAdd.setOnClickListener {
            val dateStr   = etDate.text?.toString()?.trim().orEmpty()
            val weightStr = etWeight.text?.toString()?.trim().orEmpty()

            if (dateStr.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(this, "Date and weight required", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            try {
                val date = LocalDate.parse(dateStr)   // yyyy-MM-dd
                val lbs  = weightStr.toDouble()

                vm.add(date, lbs, note = null)
                etWeight.setText("")

                // 🔔 Optional SMS alert: only if user enabled + permission granted
                maybeSendGoalReachedSms(date, lbs)

            } catch (e: Exception) {
                Toast.makeText(
                    this,
                    "Use date like 2025-10-19 and a numeric weight",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun showEditDialog(entry: WeightEntry) {
        val dialogView = LayoutInflater.from(this)
            .inflate(R.layout.dialog_weight_entry, null)

        val dDate   = dialogView.findViewById<EditText>(R.id.etDate)
        val dWeight = dialogView.findViewById<EditText>(R.id.etWeight)
        val dNote   = dialogView.findViewById<EditText>(R.id.etNote)

        dDate.setText(LocalDate.ofEpochDay(entry.dateEpochDay).toString()) // yyyy-MM-dd
        dWeight.setText(entry.weightLbs.toString())
        dNote.setText(entry.note.orEmpty())

        AlertDialog.Builder(this)
            .setTitle("Edit Weight")
            .setView(dialogView)
            .setPositiveButton("Update") { dlg, _ ->
                try {
                    val newDate = LocalDate.parse(dDate.text.toString())
                    val newLbs  = dWeight.text.toString().toDouble()
                    vm.update(
                        entry.copy(
                            dateEpochDay = newDate.toEpochDay(),
                            weightLbs = newLbs,
                            note = dNote.text.toString().ifBlank { null }
                        )
                    )
                } catch (_: Exception) {
                    Toast.makeText(this, "Invalid date/weight", Toast.LENGTH_SHORT).show()
                }
                dlg.dismiss()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    /* Send SMS */
    private fun maybeSendGoalReachedSms(date: LocalDate, lbs: Double) {
        val enabled = SmsSettings.isEnabled(this)
        val goal    = SmsSettings.goal(this)
        val phone   = SmsSettings.phone(this)

        if (!enabled || goal == null || phone.isNullOrBlank() || lbs > goal) return

        val msg = "Congrats! Goal $goal lb reached: $lbs lb on $date."
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, msg, null, null)
            Toast.makeText(this, "Goal reached! SMS alert sent.", Toast.LENGTH_SHORT).show()
        } catch (_: SecurityException) {
            // Permission missing/revoked: disable quietly so app keeps working
            SmsSettings.setEnabled(this, false)
            Toast.makeText(this, "SMS permission missing. Notifications disabled.", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "SMS failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
