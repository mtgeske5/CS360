package com.example.weighttracker.auth

import java.security.SecureRandom
import java.util.Base64
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object PasswordHasher {
    private const val ITERATIONS = 65_536
    private const val KEY_LENGTH = 256

    private fun newSalt(): ByteArray = ByteArray(16).also {
        SecureRandom().nextBytes(it)
    }

    fun hash(password: String): String {
        val salt = newSalt()
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        val skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        val hash = skf.generateSecret(spec).encoded
        return "${b64(salt)}:${b64(hash)}"
    }

    fun verify(password: String, stored: String): Boolean {
        val (saltB64, hashB64) = stored.split(":")
        val salt = fromB64(saltB64)
        val spec = PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEY_LENGTH)
        val skf = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
        val candidate = skf.generateSecret(spec).encoded
        return constantTimeEquals(hashB64, b64(candidate))
    }

    private fun b64(b: ByteArray) = Base64.getEncoder().encodeToString(b)
    private fun fromB64(s: String) = Base64.getDecoder().decode(s)

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var res = 0
        for (i in a.indices) res = res or (a[i].code xor b[i].code)
        return res == 0
    }
}
