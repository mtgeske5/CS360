package com.example.weighttracker.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.example.weighttracker.auth.AuthViewModel

@Composable
fun RegisterScreen(
    vm: AuthViewModel,
    onBackToLogin: () -> Unit
) {
    val state by vm.state.collectAsState()

    var username by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(Modifier.padding(24.dp).fillMaxWidth()) {
        Text("Create Account", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(value = username, onValueChange = { username = it },
            label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = email, onValueChange = { email = it },
            label = { Text("Email (optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(8.dp))
        OutlinedTextField(value = password, onValueChange = { password = it },
            label = { Text("Password (min 6)") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth())

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { vm.register(username, email.ifBlank { null }, password) },
            enabled = !state.isBusy && username.isNotBlank() && password.length >= 6,
            modifier = Modifier.fillMaxWidth()
        ) { Text("Register") }

        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onBackToLogin, enabled = !state.isBusy, modifier = Modifier.fillMaxWidth()) {
            Text("Back to Login")
        }

        state.message?.let {
            Spacer(Modifier.height(8.dp))
            Text(it)
        }
    }
}
