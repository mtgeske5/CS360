package com.example.weighttracker.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val isBusy: Boolean = false,
    val message: String? = null,
    val loggedIn: Boolean = false
)

class AuthViewModel(private val repo: AuthRepository) : ViewModel() {
    private val _state = MutableStateFlow(AuthUiState())
    val state: StateFlow<AuthUiState> = _state

    fun login(username: String, password: String) {
        _state.value = _state.value.copy(isBusy = true, message = null)
        viewModelScope.launch {
            val result = repo.login(username.trim(), password)
            _state.value = if (result.isSuccess)
                AuthUiState(loggedIn = true)
            else
                AuthUiState(message = result.exceptionOrNull()?.message)
        }
    }

    fun register(username: String, email: String?, password: String) {
        _state.value = _state.value.copy(isBusy = true, message = null)
        viewModelScope.launch {
            val result = repo.register(username.trim(), email?.trim(), password)
            _state.value = if (result.isSuccess)
                AuthUiState(message = "Account created. Please log in.")
            else
                AuthUiState(message = result.exceptionOrNull()?.message)
        }
    }

    fun clearMessage() { _state.value = _state.value.copy(message = null) }
}
