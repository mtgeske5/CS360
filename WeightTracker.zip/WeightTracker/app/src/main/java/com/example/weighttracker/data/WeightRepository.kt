package com.example.weighttracker.data

import kotlinx.coroutines.flow.Flow

class WeightRepository(private val db: AppDatabase) {
    private val dao = db.weightDao()

    fun observeAll(): Flow<List<WeightEntry>> = dao.observeAll()

    suspend fun add(dateEpochDay: Long, weightLbs: Double, note: String?) {
        dao.insert(WeightEntry(dateEpochDay = dateEpochDay, weightLbs = weightLbs, note = note))
    }

    suspend fun update(entry: WeightEntry) = dao.update(entry)

    suspend fun delete(entry: WeightEntry) = dao.delete(entry)
}
