// app/src/main/java/com/example/weighttracker/auth/SmsSettings.kt
package com.example.weighttracker.auth

import android.content.Context

object SmsSettings {
    private const val PREF = "sms_prefs"
    private const val K_ENABLED = "enabled"
    private const val K_PHONE = "phone"
    private const val K_GOAL = "goal_lbs"

    fun setEnabled(ctx: Context, v: Boolean) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putBoolean(K_ENABLED, v).apply()
    fun isEnabled(ctx: Context) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getBoolean(K_ENABLED, false)

    fun setPhone(ctx: Context, phone: String) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(K_PHONE, phone).apply()
    fun phone(ctx: Context): String? =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(K_PHONE, null)

    fun setGoal(ctx: Context, goalLbs: Double) =
        ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putFloat(K_GOAL, goalLbs.toFloat()).apply()
    fun goal(ctx: Context): Double? {
        val v = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getFloat(K_GOAL, Float.NaN)
        return if (v.isNaN()) null else v.toDouble()
    }
}
