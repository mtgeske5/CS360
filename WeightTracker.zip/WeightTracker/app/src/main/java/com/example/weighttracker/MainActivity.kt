package com.example.weighttracker

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.weighttracker.auth.AuthViewModel
import com.example.weighttracker.auth.AuthViewModelFactory
import com.example.weighttracker.data.AppDatabase
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import kotlinx.coroutines.launch
import com.example.weighttracker.userinterface.HomeActivity

class MainActivity : AppCompatActivity() {

    private val authVm: AuthViewModel by viewModels {
        AuthViewModelFactory(AppDatabase.get(this))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val etUsername = findViewById<TextInputEditText>(R.id.etUsername)
        val etPassword = findViewById<TextInputEditText>(R.id.etPassword)
        val btnLogin   = findViewById<MaterialButton>(R.id.btnLogin)
        val btnCreate  = findViewById<MaterialButton>(R.id.btnCreateAccount)


        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                authVm.state.collect { state ->

                    state.message?.let {
                        Toast.makeText(this@MainActivity, it, Toast.LENGTH_SHORT).show()
                        authVm.clearMessage()
                    }

                    if (state.loggedIn) {
                        startActivity(Intent(this@MainActivity, HomeActivity::class.java))
                        finish()
                    }


                    btnLogin.isEnabled = !state.isBusy
                    btnCreate.isEnabled = !state.isBusy
                }
            }
        }

        btnLogin.setOnClickListener {
            val u = etUsername.text?.toString()?.trim().orEmpty()
            val p = etPassword.text?.toString().orEmpty()
            if (u.isEmpty() || p.isEmpty()) {
                Toast.makeText(this, "Enter username and password", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            authVm.login(u, p)
        }

        // Go to Create Account screen (new activity below)
        btnCreate.setOnClickListener {
            startActivity(Intent(this, CreateAccountActivity::class.java))

        }
    }
}
