package com.example.weighttracker.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.weighttracker.data.AppDatabase

class AuthViewModelFactory(db: AppDatabase) : ViewModelProvider.Factory {
    private val repo = AuthRepository(db)
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return AuthViewModel(repo) as T
    }
}
