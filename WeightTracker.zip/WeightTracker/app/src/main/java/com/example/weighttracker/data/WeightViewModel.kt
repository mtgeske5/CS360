package com.example.weighttracker.data

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.time.LocalDate

class WeightViewModel(private val repo: WeightRepository): ViewModel() {
    val weights: StateFlow<List<WeightEntry>> =
        repo.observeAll().stateIn(viewModelScope, SharingStarted.Lazily, emptyList())

    fun add(date: LocalDate, lbs: Double, note: String?) {
        viewModelScope.launch { repo.add(date.toEpochDay(), lbs, note) }
    }

    fun update(entry: WeightEntry) {
        viewModelScope.launch { repo.update(entry) }
    }

    fun delete(entry: WeightEntry) {
        viewModelScope.launch { repo.delete(entry) }
    }
}

class WeightViewModelFactory(db: AppDatabase): ViewModelProvider.Factory {
    private val repo = WeightRepository(db)
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = WeightViewModel(repo) as T
}
