package com.example.weighttracker.auth

import com.example.weighttracker.data.AppDatabase
import com.example.weighttracker.data.User

class AuthRepository(private val db: AppDatabase) {
    private val userDao = db.userDao()

    suspend fun register(username: String, email: String?, password: String): Result<Unit> {
        if (username.isBlank() || password.length < 6) {
            return Result.failure(IllegalArgumentException("Invalid input"))
        }
        val exists = userDao.usernameExists(username) > 0
        if (exists) return Result.failure(IllegalStateException("Username already exists"))

        val hash = PasswordHasher.hash(password)
        userDao.insert(User(username = username, email = email, passwordHash = hash))
        return Result.success(Unit)
    }

    suspend fun login(username: String, password: String): Result<Unit> {
        val user = userDao.findByUsername(username) ?: return Result.failure(Exception("No such user"))
        val ok = PasswordHasher.verify(password, user.passwordHash)
        return if (ok) Result.success(Unit) else Result.failure(Exception("Invalid credentials"))
    }
}
