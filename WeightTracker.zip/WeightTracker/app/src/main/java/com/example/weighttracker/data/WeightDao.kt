package com.example.weighttracker.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface WeightDao {
    @Query("SELECT * FROM weights ORDER BY dateEpochDay DESC, id DESC")
    fun observeAll(): Flow<List<WeightEntry>>

    @Insert
    suspend fun insert(entry: WeightEntry): Long

    @Update
    suspend fun update(entry: WeightEntry)

    @Delete
    suspend fun delete(entry: WeightEntry)

    @Query("SELECT * FROM weights WHERE id = :id")
    suspend fun getById(id: Long): WeightEntry?
}
